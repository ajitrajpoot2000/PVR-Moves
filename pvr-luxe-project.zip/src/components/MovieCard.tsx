import { Link } from "react-router-dom";
import { Star } from "lucide-react";
import type { Movie } from "@/data/movies";

interface MovieCardProps {
  movie: Movie;
  size?: "small" | "medium";
}

export const MovieCard = ({ movie, size = "medium" }: MovieCardProps) => {
  return (
    <Link to={`/movie/${movie.id}`} className="group block flex-shrink-0">
      <div className={`relative overflow-hidden rounded-lg ${size === "small" ? "w-36" : "w-44"}`}>
        <img
          src={movie.poster}
          alt={movie.title}
          loading="lazy"
          className="w-full aspect-[2/3] object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {movie.format.length > 0 && (
          <div className="absolute top-2 left-2 flex flex-wrap gap-1">
            {movie.format.slice(0, 2).map((f) => (
              <span
                key={f}
                className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-gold/90 text-primary-foreground"
              >
                {f}
              </span>
            ))}
          </div>
        )}
      </div>
      <div className="mt-2 w-44">
        <h3 className="font-body text-sm font-bold uppercase tracking-wide truncate">
          {movie.title}
        </h3>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">
          {movie.certification} • {movie.genre}
        </p>
        {movie.rating > 0 && (
          <div className="flex items-center gap-1 mt-1">
            <Star className="w-3 h-3 fill-gold text-gold" />
            <span className="text-xs font-semibold">{movie.rating}</span>
          </div>
        )}
      </div>
    </Link>
  );
};
