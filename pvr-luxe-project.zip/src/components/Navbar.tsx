import { Link, useLocation, useNavigate } from "react-router-dom";
import { MapPin, Bell, User, Film, Building2, Tag, ChevronLeft, Utensils, Gift } from "lucide-react";

export const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === "/";
  const navItems = [
    { label: "Movies", path: "/" },
    { label: "Cinemas", path: "/cinemas" },
    { label: "Offers", path: "/offers" },
    { label: "Food & Bev", path: "/food-bev" },
    { label: "Gift Cards", path: "/gift-cards" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          {!isHome && (
            <button onClick={() => navigate(-1)} className="text-foreground hover:text-gold transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}
          <Link to="/" className="font-display text-xl font-bold italic text-gold">
            PVR LUXE
          </Link>
        </div>
        <div className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.label}
              to={item.path}
              className={`text-sm font-medium transition-colors ${
                location.pathname === item.path
                  ? "text-gold border-b-2 border-gold pb-0.5"
                  : "text-foreground hover:text-gold"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <button className="text-gold hover:text-gold-light transition-colors">
            <MapPin className="w-5 h-5" />
          </button>
          <button className="text-foreground hover:text-gold transition-colors">
            <Bell className="w-5 h-5" />
          </button>
          <button className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
            <User className="w-4 h-4" />
          </button>
        </div>
      </div>
    </nav>
  );
};

export const BottomNav = () => {
  const location = useLocation();
  const items = [
    { icon: Film, label: "HOME", path: "/" },
    { icon: Building2, label: "CINEMAS", path: "/cinemas" },
    { icon: Tag, label: "OFFERS", path: "/offers" },
    { icon: User, label: "PROFILE", path: "/profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-t border-border md:hidden">
      <div className="flex items-center justify-around h-16">
        {items.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.label}
              to={item.path}
              className={`flex flex-col items-center gap-1 text-xs font-medium transition-colors ${
                isActive ? "text-gold" : "text-muted-foreground"
              }`}
            >
              {isActive ? (
                <div className="bg-gold rounded-lg p-2">
                  <item.icon className="w-4 h-4 text-primary-foreground" />
                </div>
              ) : (
                <item.icon className="w-5 h-5" />
              )}
              <span>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};
