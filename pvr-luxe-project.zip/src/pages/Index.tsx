import { Link } from "react-router-dom";
import { Star, Play } from "lucide-react";
import { movies } from "@/data/movies";
import { MovieCard } from "@/components/MovieCard";
import heroImage from "@/assets/hero-movie.jpg";
import directorsCut from "@/assets/luxe-directors-cut.jpg";
import imaxImage from "@/assets/luxe-imax.jpg";
import fourDxImage from "@/assets/luxe-4dx.jpg";
import { useState } from "react";

const HeroSection = () => {
  const featuredMovie = movies[0];
  return (
    <section className="relative h-[85vh] min-h-[600px]">
      <div className="absolute inset-0">
        <img src={heroImage} alt={featuredMovie.title} className="w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-transparent" />
      </div>
      <div className="container relative z-10 flex flex-col justify-end h-full pb-20">
        <span className="inline-block px-3 py-1 text-xs font-bold uppercase tracking-wider bg-destructive rounded w-fit mb-4">
          Now in Cinemas
        </span>
        <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-black uppercase tracking-tight mb-4">
          {featuredMovie.title}
        </h1>
        <div className="flex items-center gap-3 text-sm text-muted-foreground mb-3">
          <span className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-gold text-gold" />
            <span className="font-bold text-foreground">{featuredMovie.rating}</span> IMDB
          </span>
          <span>•</span>
          <span>{featuredMovie.genre}</span>
          <span>•</span>
          <span>{featuredMovie.duration}</span>
        </div>
        <p className="text-sm text-muted-foreground max-w-lg mb-6">{featuredMovie.description}</p>
        <div className="flex items-center gap-3">
          <Link
            to={`/movie/${featuredMovie.id}/showtimes`}
            className="gradient-gold text-primary-foreground font-bold text-sm px-6 py-3 rounded-lg shadow-gold flex items-center gap-2 hover:opacity-90 transition-opacity"
          >
            🎬 BOOK TICKETS
          </Link>
          <button className="border border-border text-foreground font-medium text-sm px-6 py-3 rounded-lg hover:bg-secondary transition-colors flex items-center gap-2">
            <Play className="w-4 h-4" /> VIEW TRAILER
          </button>
        </div>
      </div>
    </section>
  );
};

const NowShowing = () => {
  const nowShowing = movies.filter((m) => m.status === "now_showing");
  return (
    <section className="container py-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-2xl font-bold italic">Now Showing</h2>
          <p className="text-sm text-muted-foreground">Experience the latest blockbusters in luxury</p>
        </div>
        <Link to="/movies" className="text-gold text-sm font-semibold flex items-center gap-1 hover:underline">
          VIEW ALL →
        </Link>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
        {nowShowing.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
    </section>
  );
};

const LuxeCollection = () => (
  <section className="container py-12">
    <div className="text-center mb-8">
      <h2 className="font-display text-2xl font-bold uppercase tracking-widest">The Luxe Collection</h2>
      <p className="text-sm text-muted-foreground mt-2">
        Elevate your cinema experience with our premium auditorium formats designed for ultimate immersion.
      </p>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="relative rounded-xl overflow-hidden h-80 group">
        <img src={directorsCut} alt="Director's Cut" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" width={512} height={640} />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
        <div className="absolute bottom-6 left-6">
          <h3 className="font-display text-2xl italic text-gold">Director's Cut</h3>
          <p className="text-sm text-muted-foreground mt-1 max-w-xs">
            Concierge service, fine dining, and unparalleled comfort in our most exclusive format.
          </p>
          <button className="mt-3 border border-gold text-gold text-xs font-bold px-4 py-2 rounded hover:bg-gold hover:text-primary-foreground transition-colors">
            EXPLORE
          </button>
        </div>
      </div>
      <div className="grid grid-rows-2 gap-4">
        <div className="relative rounded-xl overflow-hidden group">
          <img src={imaxImage} alt="IMAX with Laser" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" width={640} height={512} />
          <div className="absolute inset-0 bg-gradient-to-l from-background/80 to-transparent" />
          <div className="absolute bottom-4 right-4 text-right">
            <h3 className="font-display text-lg font-bold">IMAX with Laser</h3>
            <p className="text-xs text-muted-foreground">Precision sound and monumental scale.</p>
            <span className="text-gold text-xs font-bold">LEARN MORE →</span>
          </div>
        </div>
        <div className="relative rounded-xl overflow-hidden group">
          <img src={fourDxImage} alt="4DX Fusion" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" width={640} height={512} />
          <div className="absolute inset-0 bg-gradient-to-l from-background/80 to-transparent" />
          <div className="absolute bottom-4 right-4 text-right">
            <h3 className="font-display text-lg font-bold">4DX Fusion</h3>
            <p className="text-xs text-muted-foreground">Motion, wind, water, and scent effects.</p>
            <span className="text-gold text-xs font-bold">LEARN MORE →</span>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ComingSoon = () => {
  const comingSoon = movies.filter((m) => m.status === "coming_soon");
  return (
    <section className="container py-12">
      <div className="mb-6">
        <h2 className="font-display text-2xl font-bold italic">Coming Soon</h2>
        <p className="text-sm text-muted-foreground">Mark your calendars for these upcoming releases</p>
      </div>
      <div className="flex gap-6 overflow-x-auto pb-4">
        {comingSoon.map((movie) => (
          <div key={movie.id} className="flex-shrink-0">
            <div className="relative w-44">
              <img src={movie.poster} alt={movie.title} loading="lazy" className="w-full aspect-[2/3] object-cover rounded-lg" />
              <span className="absolute top-2 right-2 bg-destructive text-foreground text-[10px] font-bold px-2 py-0.5 rounded">
                {movie.releaseDate.split(",")[0].toUpperCase().slice(0, 6)}
              </span>
            </div>
            <h3 className="font-body text-sm font-bold uppercase mt-2 tracking-wide">{movie.title}</h3>
            <p className="text-xs text-muted-foreground">Director: {movie.director}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

const Newsletter = () => {
  const [email, setEmail] = useState("");
  return (
    <section className="container py-12 mb-16 md:mb-0">
      <div className="bg-card rounded-2xl p-8 text-center max-w-lg mx-auto border border-border">
        <div className="text-3xl mb-3">✉️</div>
        <h2 className="font-display text-xl font-bold uppercase tracking-widest">Be the First to Know</h2>
        <p className="text-sm text-muted-foreground mt-2">
          Get exclusive early access to tickets, special events, and luxury offers delivered to your inbox.
        </p>
        <div className="flex mt-4 gap-2">
          <input
            type="email"
            placeholder="Your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 bg-secondary border border-border rounded-lg px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold"
          />
          <button className="gradient-gold text-primary-foreground font-bold text-sm px-5 py-2 rounded-lg shadow-gold hover:opacity-90 transition-opacity">
            JOIN NOW
          </button>
        </div>
      </div>
    </section>
  );
};

const Index = () => {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <NowShowing />
      <LuxeCollection />
      <ComingSoon />
      <Newsletter />
    </div>
  );
};

export default Index;
