import { Building2, MapPin, Clock, Star } from "lucide-react";

const cinemas = [
  { id: 1, name: "PVR LUXE Downtown", address: "123 Main St, Downtown", screens: 8, formats: ["IMAX", "4DX", "LUXE"], rating: 4.8, distance: "1.2 km" },
  { id: 2, name: "PVR LUXE Mall of Stars", address: "Mall of Stars, Level 3", screens: 12, formats: ["IMAX 3D", "Dolby Atmos", "LUXE"], rating: 4.9, distance: "3.5 km" },
  { id: 3, name: "PVR LUXE Riverside", address: "45 River Walk, Riverside", screens: 6, formats: ["4DX", "LUXE"], rating: 4.6, distance: "5.1 km" },
  { id: 4, name: "PVR LUXE Tech Park", address: "Tech Park Boulevard, Sector 5", screens: 10, formats: ["IMAX", "Dolby Atmos", "4DX", "LUXE"], rating: 4.7, distance: "7.8 km" },
  { id: 5, name: "PVR LUXE Heritage", address: "22 Heritage Lane, Old Town", screens: 4, formats: ["Director's Cut", "LUXE"], rating: 4.5, distance: "9.2 km" },
  { id: 6, name: "PVR LUXE Airport City", address: "Airport City Mall, Gate 3", screens: 8, formats: ["IMAX", "LUXE"], rating: 4.4, distance: "12.0 km" },
];

const Cinemas = () => {
  return (
    <div className="min-h-screen bg-background pt-20 pb-24 md:pb-8">
      <div className="container">
        <div className="flex items-center gap-3 mb-2">
          <Building2 className="w-7 h-7 text-gold" />
          <h1 className="font-display text-3xl font-bold text-foreground">Our Cinemas</h1>
        </div>
        <p className="text-muted-foreground mb-8 max-w-xl">Find a PVR LUXE cinema near you for the ultimate movie experience.</p>

        <div className="grid gap-4">
          {cinemas.map(cinema => (
            <div key={cinema.id} className="bg-surface-elevated rounded-xl p-6 border border-border hover:border-gold/30 transition-colors">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground mb-1">{cinema.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{cinema.address}</span>
                    <span className="text-gold">• {cinema.distance}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {cinema.formats.map(f => (
                      <span key={f} className="text-xs bg-gold/10 text-gold px-2.5 py-1 rounded-full">{f}</span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="flex items-center gap-1 text-gold">
                      <Star className="w-4 h-4 fill-gold" />
                      <span className="font-bold">{cinema.rating}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">Rating</span>
                  </div>
                  <div className="text-center">
                    <span className="font-bold text-foreground">{cinema.screens}</span>
                    <div className="text-xs text-muted-foreground">Screens</div>
                  </div>
                  <button className="bg-gold text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-semibold hover:bg-gold-light transition-colors">
                    View Shows
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Cinemas;
