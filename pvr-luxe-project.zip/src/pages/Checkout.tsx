import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import { ArrowLeft, Lock, CreditCard, Smartphone, Building, Plus, Minus, Tag, Gift, X, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { movies } from "@/data/movies";

const foodItems = [
  { id: 1, name: "Classic Butter Popcorn", price: 6.99, emoji: "🍿", size: "Large" },
  { id: 2, name: "Caramel Crunch Popcorn", price: 7.99, emoji: "🍿", size: "Large" },
  { id: 3, name: "Nachos Grande", price: 8.99, emoji: "🌮", size: "Regular" },
  { id: 4, name: "Coca-Cola", price: 4.99, emoji: "🥤", size: "Large" },
  { id: 5, name: "Iced Mocha", price: 5.99, emoji: "☕", size: "Regular" },
  { id: 6, name: "Chicken Wings", price: 10.99, emoji: "🍗", size: "6 pcs" },
  { id: 7, name: "Loaded Fries", price: 7.99, emoji: "🍟", size: "Regular" },
  { id: 8, name: "Chocolate Brownie", price: 5.99, emoji: "🍫", size: "1 pc" },
];

const availableOffers = [
  { code: "FIRST50", discount: 50, type: "percent" as const, maxDiscount: 15, label: "50% Off (Max $15)" },
  { code: "IMAX5", discount: 5, type: "flat" as const, maxDiscount: 5, label: "$5 Off IMAX" },
  { code: "COMBO999", discount: 3, type: "flat" as const, maxDiscount: 3, label: "$3 Off on Food Combo" },
  { code: "STUDENT25", discount: 25, type: "percent" as const, maxDiscount: 10, label: "25% Student Discount (Max $10)" },
];

const Checkout = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const movie = movies.find((m) => m.id === Number(id));
  const seats = searchParams.get("seats")?.split(",") || ["J5", "J6"];
  const total = Number(searchParams.get("total")) || 56;
  const [paymentMethod, setPaymentMethod] = useState<"card" | "apple">("card");
  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<typeof availableOffers[0] | null>(null);
  const [promoError, setPromoError] = useState("");
  const [giftCardCode, setGiftCardCode] = useState("");
  const [appliedGiftCard, setAppliedGiftCard] = useState<{ code: string; balance: number } | null>(null);
  const [giftCardError, setGiftCardError] = useState("");
  const [foodCart, setFoodCart] = useState<Record<number, number>>({});
  const [showAllFood, setShowAllFood] = useState(false);

  const updateFoodCart = (itemId: number, delta: number) => {
    setFoodCart((prev) => {
      const val = (prev[itemId] || 0) + delta;
      if (val <= 0) {
        const { [itemId]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [itemId]: val };
    });
  };

  const foodTotal = Object.entries(foodCart).reduce((sum, [itemId, qty]) => {
    const item = foodItems.find((f) => f.id === Number(itemId));
    return sum + (item?.price || 0) * qty;
  }, 0);

  const basePrice = total;
  const convenienceFee = 6.5;
  const gst = Number(((basePrice + foodTotal) * 0.18).toFixed(2));
  const subtotal = basePrice + foodTotal + convenienceFee + gst;

  // Calculate promo discount
  let promoDiscount = 0;
  if (appliedPromo) {
    if (appliedPromo.type === "percent") {
      promoDiscount = Math.min((subtotal * appliedPromo.discount) / 100, appliedPromo.maxDiscount);
    } else {
      promoDiscount = appliedPromo.discount;
    }
  }

  // Gift card deduction
  const giftCardDeduction = appliedGiftCard ? Math.min(appliedGiftCard.balance, subtotal - promoDiscount) : 0;

  const grandTotal = Math.max(0, subtotal - promoDiscount - giftCardDeduction);

  const applyPromo = () => {
    setPromoError("");
    const offer = availableOffers.find((o) => o.code === promoCode.toUpperCase());
    if (offer) {
      setAppliedPromo(offer);
      setPromoCode("");
    } else {
      setPromoError("Invalid promo code. Try FIRST50, IMAX5, STUDENT25, or COMBO999.");
    }
  };

  const applyGiftCard = () => {
    setGiftCardError("");
    const code = giftCardCode.toUpperCase().trim();
    if (code.startsWith("GC") && code.length >= 6) {
      // Simulate gift card with random balance
      const balance = [25, 50, 75, 100][Math.floor(code.charCodeAt(2) % 4)];
      setAppliedGiftCard({ code, balance });
      setGiftCardCode("");
    } else {
      setGiftCardError("Invalid gift card. Try a code starting with 'GC' (e.g., GC123456).");
    }
  };

  const handlePayment = () => {
    const foodCartItems = Object.entries(foodCart).map(([itemId, qty]) => {
      const item = foodItems.find((f) => f.id === Number(itemId));
      return { name: item?.name || "", qty, price: item?.price || 0 };
    });

    const bookingData = {
      movieId: Number(id),
      movieTitle: movie?.title || "",
      moviePoster: movie?.poster || "",
      seats,
      basePrice,
      foodItems: foodCartItems,
      foodTotal,
      convenienceFee,
      gst,
      promoDiscount,
      promoCode: appliedPromo?.code || "",
      giftCardDeduction,
      giftCardCode: appliedGiftCard?.code || "",
      grandTotal,
      paymentMethod,
      bookingId: `PVR${Date.now().toString(36).toUpperCase()}`,
      bookingDate: new Date().toISOString(),
      cinema: "PVR LUXE, Director's Cut",
      screen: "Screen 4",
      showDate: "Oct 24, 2024",
      showTime: "07:30 PM",
    };

    localStorage.setItem("pvr_booking", JSON.stringify(bookingData));
    navigate(`/movie/${id}/confirmation`);
  };

  if (!movie) return null;

  const displayedFood = showAllFood ? foodItems : foodItems.slice(0, 4);

  return (
    <div className="min-h-screen pt-16">
      <div className="container py-8 pb-24 md:pb-8">
        <Link to={`/movie/${id}/seats`} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to seat selection
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left */}
          <div className="lg:col-span-3 space-y-6">
            <div>
              <h1 className="font-display text-3xl font-bold">Secure Checkout</h1>
              <p className="text-sm text-muted-foreground mt-1">Review your selection, add food & drinks, apply offers, and complete your booking.</p>
            </div>

            {/* Food & Beverages */}
            <div className="bg-card rounded-xl p-6 border border-border">
              <h3 className="font-bold flex items-center gap-2 mb-1">🍿 Add Food & Beverages</h3>
              <p className="text-xs text-muted-foreground mb-4">Pre-order and skip the queue — delivered to your seat!</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {displayedFood.map((item) => {
                  const qty = foodCart[item.id] || 0;
                  return (
                    <div key={item.id} className="flex items-center justify-between bg-secondary/50 rounded-lg p-3 border border-border">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{item.emoji}</span>
                        <div>
                          <p className="text-sm font-medium">{item.name}</p>
                          <p className="text-xs text-muted-foreground">{item.size} • ${item.price.toFixed(2)}</p>
                        </div>
                      </div>
                      {qty === 0 ? (
                        <button
                          onClick={() => updateFoodCart(item.id, 1)}
                          className="text-gold border border-gold text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-gold hover:text-primary-foreground transition-colors"
                        >
                          ADD
                        </button>
                      ) : (
                        <div className="flex items-center gap-2 bg-background rounded-lg px-2 py-1 border border-gold/30">
                          <button onClick={() => updateFoodCart(item.id, -1)} className="text-gold"><Minus className="w-3.5 h-3.5" /></button>
                          <span className="text-sm font-bold w-4 text-center">{qty}</span>
                          <button onClick={() => updateFoodCart(item.id, 1)} className="text-gold"><Plus className="w-3.5 h-3.5" /></button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              {!showAllFood && (
                <button onClick={() => setShowAllFood(true)} className="text-gold text-sm font-medium mt-3 hover:underline">
                  View all {foodItems.length} items →
                </button>
              )}
              {foodTotal > 0 && (
                <div className="mt-3 flex items-center justify-between bg-gold/10 rounded-lg p-3">
                  <span className="text-sm font-medium text-gold">Food & Beverages Total</span>
                  <span className="text-sm font-bold text-gold">${foodTotal.toFixed(2)}</span>
                </div>
              )}
            </div>

            {/* Promo Code */}
            <div className="bg-card rounded-xl p-6 border border-border">
              <h3 className="font-bold flex items-center gap-2 mb-4">
                <Tag className="w-4 h-4 text-gold" /> Offers & Promo Codes
              </h3>
              {appliedPromo ? (
                <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500" />
                    <div>
                      <span className="text-sm font-bold text-emerald-400">{appliedPromo.code}</span>
                      <span className="text-xs text-muted-foreground ml-2">— {appliedPromo.label}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold text-emerald-400">-${promoDiscount.toFixed(2)}</span>
                    <button onClick={() => setAppliedPromo(null)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter Promo Code"
                      value={promoCode}
                      onChange={(e) => { setPromoCode(e.target.value); setPromoError(""); }}
                      onKeyDown={(e) => e.key === "Enter" && applyPromo()}
                      className="flex-1 bg-secondary border border-border rounded-lg px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold"
                    />
                    <button onClick={applyPromo} className="border border-gold text-gold font-bold text-sm px-5 py-2 rounded-lg hover:bg-gold hover:text-primary-foreground transition-colors">
                      APPLY
                    </button>
                  </div>
                  {promoError && <p className="text-xs text-red-400 mt-2">{promoError}</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {availableOffers.map((o) => (
                      <button
                        key={o.code}
                        onClick={() => { setAppliedPromo(o); setPromoError(""); }}
                        className="text-xs bg-gold/10 text-gold px-3 py-1.5 rounded-full border border-gold/20 hover:bg-gold/20 transition-colors"
                      >
                        {o.code}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Gift Card */}
            <div className="bg-card rounded-xl p-6 border border-border">
              <h3 className="font-bold flex items-center gap-2 mb-4">
                <Gift className="w-4 h-4 text-gold" /> Apply Gift Card
              </h3>
              {appliedGiftCard ? (
                <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-500" />
                    <div>
                      <span className="text-sm font-bold text-emerald-400">{appliedGiftCard.code}</span>
                      <span className="text-xs text-muted-foreground ml-2">— Balance: ${appliedGiftCard.balance.toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold text-emerald-400">-${giftCardDeduction.toFixed(2)}</span>
                    <button onClick={() => setAppliedGiftCard(null)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter Gift Card Code (e.g. GC123456)"
                      value={giftCardCode}
                      onChange={(e) => { setGiftCardCode(e.target.value); setGiftCardError(""); }}
                      onKeyDown={(e) => e.key === "Enter" && applyGiftCard()}
                      className="flex-1 bg-secondary border border-border rounded-lg px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold"
                    />
                    <button onClick={applyGiftCard} className="border border-gold text-gold font-bold text-sm px-5 py-2 rounded-lg hover:bg-gold hover:text-primary-foreground transition-colors">
                      APPLY
                    </button>
                  </div>
                  {giftCardError && <p className="text-xs text-red-400 mt-2">{giftCardError}</p>}
                </>
              )}
            </div>

            {/* Payment Methods */}
            <div>
              <h3 className="font-bold flex items-center gap-2 mb-4">
                <span className="w-1 h-5 bg-gold rounded-full" />
                Payment Methods
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setPaymentMethod("card")}
                  className={`p-6 rounded-xl border transition-colors relative ${paymentMethod === "card" ? "border-gold bg-gold/5" : "border-border bg-card"}`}
                >
                  {paymentMethod === "card" && (
                    <span className="absolute top-3 right-3 w-5 h-5 bg-gold rounded-full flex items-center justify-center text-primary-foreground text-xs">✓</span>
                  )}
                  <CreditCard className="w-6 h-6 mb-8 text-muted-foreground" />
                  <p className="font-bold text-sm">•••• •••• •••• 4242</p>
                  <p className="text-xs text-muted-foreground">VISA | EXP: 12/26</p>
                </button>
                <button
                  onClick={() => setPaymentMethod("apple")}
                  className={`p-6 rounded-xl border transition-colors relative ${paymentMethod === "apple" ? "border-gold bg-gold/5" : "border-border bg-card"}`}
                >
                  <Smartphone className="w-6 h-6 mb-8 text-muted-foreground" />
                  <p className="font-bold text-sm">Apple Pay</p>
                  <p className="text-xs text-muted-foreground">LINKED TO ****7890</p>
                </button>
              </div>

              <div className="bg-card rounded-xl p-6 border border-border mt-4 space-y-4">
                <h4 className="font-semibold">Credit or Debit Card</h4>
                <div>
                  <label className="text-xs text-muted-foreground uppercase tracking-wider block mb-1">Card Number</label>
                  <div className="relative">
                    <input placeholder="0000 0000 0000 0000" className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold" />
                    <CreditCard className="absolute right-3 top-3 w-5 h-5 text-muted-foreground" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-muted-foreground uppercase tracking-wider block mb-1">Expiry Date</label>
                    <input placeholder="MM/YY" className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold" />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground uppercase tracking-wider block mb-1">CVV</label>
                    <input placeholder="***" className="w-full bg-secondary border border-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-gold" />
                  </div>
                </div>
              </div>

              <div className="space-y-2 mt-4">
                {[
                  { icon: Building, label: "Net Banking" },
                  { icon: Smartphone, label: "UPI / QR Code" },
                ].map((m) => (
                  <button key={m.label} className="w-full flex items-center justify-between bg-card border border-border rounded-xl px-6 py-4 hover:border-gold/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <m.icon className="w-5 h-5 text-muted-foreground" />
                      <span className="font-medium text-sm">{m.label}</span>
                    </div>
                    <span className="text-muted-foreground">›</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right - Order Summary */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-card rounded-xl border border-border overflow-hidden sticky top-20">
              <div className="relative h-48">
                <img src={movie.poster} alt={movie.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                <div className="absolute bottom-3 left-4">
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-gold text-primary-foreground rounded">DIRECTOR'S CUT</span>
                  <h3 className="font-display text-xl font-bold mt-1">{movie.title}</h3>
                </div>
              </div>
              <div className="p-6 space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Cinema</p>
                    <p className="font-semibold">PVR LUXE, Director's Cut</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground uppercase">Date & Time</p>
                    <p className="font-semibold">Oct 24, 07:30 PM</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Seats</p>
                    <p className="font-semibold">{seats.join(", ")} (Luxe Recliner)</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground uppercase">Screen</p>
                    <p className="font-semibold">Screen 4</p>
                  </div>
                </div>

                <div className="border-t border-border pt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Tickets ({seats.length} × ${(basePrice / seats.length).toFixed(0)})</span>
                    <span>${basePrice.toFixed(2)}</span>
                  </div>
                  {foodTotal > 0 && (
                    <>
                      <div className="flex justify-between text-gold">
                        <span>Food & Beverages</span>
                        <span>${foodTotal.toFixed(2)}</span>
                      </div>
                      {Object.entries(foodCart).map(([itemId, qty]) => {
                        const item = foodItems.find((f) => f.id === Number(itemId));
                        return item ? (
                          <div key={itemId} className="flex justify-between text-xs text-muted-foreground pl-3">
                            <span>{item.emoji} {item.name} × {qty}</span>
                            <span>${(item.price * qty).toFixed(2)}</span>
                          </div>
                        ) : null;
                      })}
                    </>
                  )}
                  <div className="flex justify-between">
                    <span>Convenience Fees</span>
                    <span>${convenienceFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (18%)</span>
                    <span>${gst.toFixed(2)}</span>
                  </div>
                  {promoDiscount > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Promo ({appliedPromo?.code})</span>
                      <span>-${promoDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  {giftCardDeduction > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Gift Card ({appliedGiftCard?.code})</span>
                      <span>-${giftCardDeduction.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-base pt-2 border-t border-border">
                    <span>Total Amount</span>
                    <span className="text-gold">${grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  onClick={handlePayment}
                  className="w-full gradient-gold text-primary-foreground font-bold py-3 rounded-xl shadow-gold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity mt-4"
                >
                  <Lock className="w-4 h-4" /> Pay ${grandTotal.toFixed(2)}
                </button>
                <p className="text-xs text-center text-muted-foreground">
                  By clicking 'Pay', you agree to our Terms of Service and Cancellation Policy.
                </p>
              </div>
            </div>

            <div className="bg-card rounded-xl p-4 border border-border flex items-center gap-3">
              <span className="text-2xl">🎧</span>
              <div>
                <p className="text-sm font-semibold">Need help with booking?</p>
                <p className="text-xs text-muted-foreground">Call our 24/7 concierge at 1800-LUXE-PVR</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
