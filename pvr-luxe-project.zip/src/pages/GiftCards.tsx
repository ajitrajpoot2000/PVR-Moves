import { Gift, CreditCard, Send } from "lucide-react";
import { useState } from "react";

const giftCardDesigns = [
  { id: 1, name: "Gold Premiere", emoji: "🎬", gradient: "from-yellow-600 to-amber-800" },
  { id: 2, name: "Movie Night", emoji: "🌙", gradient: "from-indigo-600 to-purple-800" },
  { id: 3, name: "Celebration", emoji: "🎉", gradient: "from-rose-600 to-pink-800" },
  { id: 4, name: "Date Night", emoji: "❤️", gradient: "from-red-600 to-rose-800" },
  { id: 5, name: "Birthday Special", emoji: "🎂", gradient: "from-emerald-600 to-teal-800" },
  { id: 6, name: "Luxe Experience", emoji: "✨", gradient: "from-gold to-yellow-700" },
];

const amounts = [25, 50, 75, 100, 150, 200];

const GiftCards = () => {
  const [selectedDesign, setSelectedDesign] = useState(1);
  const [selectedAmount, setSelectedAmount] = useState(50);
  const [recipientName, setRecipientName] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [message, setMessage] = useState("");

  return (
    <div className="min-h-screen bg-background pt-20 pb-24 md:pb-8">
      <div className="container">
        <div className="flex items-center gap-3 mb-2">
          <Gift className="w-7 h-7 text-gold" />
          <h1 className="font-display text-3xl font-bold text-foreground">Gift Cards</h1>
        </div>
        <p className="text-muted-foreground mb-10 max-w-xl">Give the gift of cinema. PVR LUXE gift cards are perfect for any occasion.</p>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Left - Card Design & Amount */}
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4">Choose a Design</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
              {giftCardDesigns.map(design => (
                <button
                  key={design.id}
                  onClick={() => setSelectedDesign(design.id)}
                  className={`relative bg-gradient-to-br ${design.gradient} rounded-xl p-5 text-center transition-all ${
                    selectedDesign === design.id ? "ring-2 ring-gold scale-105" : "opacity-70 hover:opacity-100"
                  }`}
                >
                  <div className="text-3xl mb-2">{design.emoji}</div>
                  <div className="text-white text-xs font-medium">{design.name}</div>
                  <div className="absolute top-2 right-2 text-white/40 text-[10px] font-bold italic">PVR LUXE</div>
                </button>
              ))}
            </div>

            <h2 className="text-lg font-semibold text-foreground mb-4">Select Amount</h2>
            <div className="grid grid-cols-3 gap-3 mb-8">
              {amounts.map(amt => (
                <button
                  key={amt}
                  onClick={() => setSelectedAmount(amt)}
                  className={`py-3 rounded-xl text-center font-bold transition-colors ${
                    selectedAmount === amt
                      ? "bg-gold text-primary-foreground"
                      : "bg-surface-elevated text-muted-foreground hover:text-foreground border border-border"
                  }`}
                >
                  ${amt}
                </button>
              ))}
            </div>

            {/* Preview */}
            <div className={`bg-gradient-to-br ${giftCardDesigns.find(d => d.id === selectedDesign)?.gradient} rounded-2xl p-6 aspect-[1.6/1] flex flex-col justify-between`}>
              <div className="flex justify-between items-start">
                <span className="text-white/80 text-sm font-bold italic">PVR LUXE</span>
                <CreditCard className="w-6 h-6 text-white/40" />
              </div>
              <div>
                <div className="text-4xl mb-2">{giftCardDesigns.find(d => d.id === selectedDesign)?.emoji}</div>
                <div className="text-white text-2xl font-bold">${selectedAmount}.00</div>
                <div className="text-white/60 text-sm mt-1">{recipientName || "Recipient Name"}</div>
              </div>
            </div>
          </div>

          {/* Right - Recipient Details */}
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              <Send className="w-5 h-5 text-gold" /> Recipient Details
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-muted-foreground mb-1.5">Recipient's Name</label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={e => setRecipientName(e.target.value)}
                  placeholder="Enter name"
                  className="w-full bg-surface-elevated border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                />
              </div>
              <div>
                <label className="block text-sm text-muted-foreground mb-1.5">Recipient's Email</label>
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={e => setRecipientEmail(e.target.value)}
                  placeholder="Enter email"
                  className="w-full bg-surface-elevated border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold"
                />
              </div>
              <div>
                <label className="block text-sm text-muted-foreground mb-1.5">Personal Message (optional)</label>
                <textarea
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Write a personal message..."
                  rows={4}
                  className="w-full bg-surface-elevated border border-border rounded-xl px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-gold resize-none"
                />
              </div>
            </div>

            <div className="mt-8 bg-surface-elevated rounded-xl p-5 border border-border">
              <h3 className="font-semibold text-foreground mb-3">Order Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Gift Card Value</span>
                  <span className="text-foreground">${selectedAmount}.00</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Design</span>
                  <span className="text-foreground">{giftCardDesigns.find(d => d.id === selectedDesign)?.name}</span>
                </div>
                <div className="border-t border-border my-2" />
                <div className="flex justify-between font-bold text-foreground">
                  <span>Total</span>
                  <span className="text-gold">${selectedAmount}.00</span>
                </div>
              </div>
            </div>

            <button className="w-full mt-6 bg-gold text-primary-foreground py-4 rounded-xl font-bold text-lg hover:bg-gold-light transition-colors">
              Purchase Gift Card — ${selectedAmount}.00
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GiftCards;
