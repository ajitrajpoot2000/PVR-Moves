import { Utensils, Plus, Minus } from "lucide-react";
import { useState } from "react";

const foodItems = [
  { id: 1, name: "Classic Butter Popcorn", category: "Popcorn", price: 6.99, image: "🍿", description: "Freshly popped with rich golden butter" },
  { id: 2, name: "Caramel Crunch Popcorn", category: "Popcorn", price: 7.99, image: "🍿", description: "Sweet caramel coated crispy popcorn" },
  { id: 3, name: "Cheese Popcorn", category: "Popcorn", price: 7.49, image: "🧀", description: "Loaded with tangy cheddar cheese flavor" },
  { id: 4, name: "Nachos Grande", category: "Snacks", price: 8.99, image: "🌮", description: "Crispy nachos with cheese sauce & jalapeños" },
  { id: 5, name: "Chicken Wings", category: "Snacks", price: 10.99, image: "🍗", description: "Spicy buffalo wings with ranch dip" },
  { id: 6, name: "Loaded Fries", category: "Snacks", price: 7.99, image: "🍟", description: "Seasoned fries with cheese & bacon bits" },
  { id: 7, name: "Coca-Cola Large", category: "Beverages", price: 4.99, image: "🥤", description: "Ice-cold refreshing Coca-Cola" },
  { id: 8, name: "Iced Mocha", category: "Beverages", price: 5.99, image: "☕", description: "Premium iced mocha with whipped cream" },
  { id: 9, name: "Fresh Lemonade", category: "Beverages", price: 4.49, image: "🍋", description: "Freshly squeezed lemonade with mint" },
  { id: 10, name: "Craft Beer", category: "Beverages", price: 8.99, image: "🍺", description: "Local craft IPA on tap" },
  { id: 11, name: "Chocolate Brownie", category: "Desserts", price: 5.99, image: "🍫", description: "Warm fudgy brownie with ice cream" },
  { id: 12, name: "Cookie Dough Bites", category: "Desserts", price: 6.49, image: "🍪", description: "Edible cookie dough bites" },
];

const categories = ["All", "Popcorn", "Snacks", "Beverages", "Desserts"];

const FoodBev = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [cart, setCart] = useState<Record<number, number>>({});

  const filtered = activeCategory === "All" ? foodItems : foodItems.filter(i => i.category === activeCategory);

  const updateCart = (id: number, delta: number) => {
    setCart(prev => {
      const val = (prev[id] || 0) + delta;
      if (val <= 0) {
        const { [id]: _, ...rest } = prev;
        return rest;
      }
      return { ...prev, [id]: val };
    });
  };

  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);
  const totalPrice = Object.entries(cart).reduce((sum, [id, qty]) => {
    const item = foodItems.find(i => i.id === Number(id));
    return sum + (item?.price || 0) * qty;
  }, 0);

  return (
    <div className="min-h-screen bg-background pt-20 pb-24 md:pb-8">
      <div className="container">
        <div className="flex items-center gap-3 mb-8">
          <Utensils className="w-7 h-7 text-gold" />
          <h1 className="font-display text-3xl font-bold text-foreground">Food & Beverages</h1>
        </div>
        <p className="text-muted-foreground mb-8 max-w-xl">Pre-order your favorites and skip the queue. Your order will be ready at your seat.</p>

        <div className="flex gap-3 mb-8 overflow-x-auto pb-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? "bg-gold text-primary-foreground"
                  : "bg-surface-elevated text-muted-foreground hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(item => {
            const qty = cart[item.id] || 0;
            return (
              <div key={item.id} className="bg-surface-elevated rounded-xl p-5 border border-border hover:border-gold/30 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="text-4xl">{item.image}</div>
                  <span className="text-xs bg-gold/10 text-gold px-2 py-1 rounded-full">{item.category}</span>
                </div>
                <h3 className="font-semibold text-foreground mb-1">{item.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-gold font-bold text-lg">${item.price.toFixed(2)}</span>
                  {qty === 0 ? (
                    <button
                      onClick={() => updateCart(item.id, 1)}
                      className="bg-gold text-primary-foreground px-4 py-1.5 rounded-lg text-sm font-medium hover:bg-gold-light transition-colors"
                    >
                      Add
                    </button>
                  ) : (
                    <div className="flex items-center gap-3 bg-background rounded-lg px-2 py-1">
                      <button onClick={() => updateCart(item.id, -1)} className="text-gold hover:text-gold-light"><Minus className="w-4 h-4" /></button>
                      <span className="text-foreground font-medium text-sm w-4 text-center">{qty}</span>
                      <button onClick={() => updateCart(item.id, 1)} className="text-gold hover:text-gold-light"><Plus className="w-4 h-4" /></button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {totalItems > 0 && (
          <div className="fixed bottom-20 md:bottom-6 left-4 right-4 md:left-auto md:right-6 md:w-96 bg-gold text-primary-foreground rounded-xl p-4 flex items-center justify-between shadow-lg z-40">
            <div>
              <span className="font-bold">{totalItems} item{totalItems > 1 ? "s" : ""}</span>
              <span className="mx-2">•</span>
              <span className="font-bold">${totalPrice.toFixed(2)}</span>
            </div>
            <button className="bg-primary-foreground text-gold px-5 py-2 rounded-lg font-semibold text-sm">
              View Cart
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FoodBev;
