import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { Calendar, Clock, Edit } from "lucide-react";
import { movies } from "@/data/movies";

type SeatStatus = "available" | "booked" | "selected";

interface Seat {
  id: string;
  row: string;
  number: number;
  status: SeatStatus;
  category: "recliner" | "prime";
}

const generateSeats = (): Seat[] => {
  const seats: Seat[] = [];
  // Recliner row J
  const bookedRecliners = [3];
  for (let i = 1; i <= 7; i++) {
    seats.push({
      id: `J${i}`, row: "J", number: i,
      status: bookedRecliners.includes(i) ? "booked" : "available",
      category: "recliner",
    });
  }
  // Prime rows H, G
  const bookedPrime = ["G4", "G5", "H4"];
  for (const row of ["H", "G"]) {
    for (let i = 1; i <= 10; i++) {
      seats.push({
        id: `${row}${i}`, row, number: i,
        status: bookedPrime.includes(`${row}${i}`) ? "booked" : "available",
        category: "prime",
      });
    }
  }
  return seats;
};

const SeatSelection = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const movie = movies.find((m) => m.id === Number(id));
  const [seats, setSeats] = useState<Seat[]>(generateSeats);

  const toggleSeat = (seatId: string) => {
    setSeats((prev) =>
      prev.map((s) =>
        s.id === seatId && s.status !== "booked"
          ? { ...s, status: s.status === "selected" ? "available" : "selected" }
          : s
      )
    );
  };

  const selectedSeats = seats.filter((s) => s.status === "selected");
  const total = selectedSeats.reduce((sum, s) => sum + (s.category === "recliner" ? 28 : 18), 0);

  const recliners = seats.filter((s) => s.category === "recliner");
  const primeH = seats.filter((s) => s.row === "H");
  const primeG = seats.filter((s) => s.row === "G");

  if (!movie) return null;

  const seatButton = (seat: Seat) => (
    <button
      key={seat.id}
      onClick={() => toggleSeat(seat.id)}
      disabled={seat.status === "booked"}
      className={`w-9 h-9 rounded-md text-xs font-semibold transition-all ${
        seat.status === "selected"
          ? "bg-gold text-primary-foreground border-2 border-gold-light"
          : seat.status === "booked"
          ? "bg-muted/50 text-muted-foreground cursor-not-allowed"
          : "bg-secondary border border-border text-foreground hover:border-gold"
      }`}
    >
      {seat.number}
    </button>
  );

  const renderRow = (rowSeats: Seat[], label: string) => (
    <div className="flex items-center justify-center gap-1">
      <span className="text-xs text-muted-foreground w-6 text-right">{label}</span>
      <div className="flex gap-1 ml-2">
        {rowSeats.slice(0, 3).map(seatButton)}
      </div>
      <div className="w-6" />
      <div className="flex gap-1">
        {rowSeats.slice(3, rowSeats.length > 7 ? 8 : 7).map(seatButton)}
      </div>
      {rowSeats.length > 7 && (
        <>
          <div className="w-6" />
          <div className="flex gap-1">
            {rowSeats.slice(8).map(seatButton)}
          </div>
        </>
      )}
      <span className="text-xs text-muted-foreground w-6 ml-2">{label}</span>
    </div>
  );

  return (
    <div className="min-h-screen pt-16">
      <div className="container py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <span className="text-xs font-bold px-2 py-0.5 bg-gold/20 text-gold rounded">PVR LUXE SCREEN 4</span>
            <h1 className="font-display text-3xl font-black mt-2">{movie.title}</h1>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
              <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Oct 24, 2024</span>
              <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> 07:30 PM</span>
            </div>
          </div>
          <button className="flex items-center gap-2 bg-secondary px-4 py-2 rounded-lg text-sm border border-border hover:border-gold transition-colors">
            <Edit className="w-4 h-4" /> Change Show
          </button>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-8 mb-8">
          {[
            { label: "AVAILABLE", color: "bg-secondary border-border" },
            { label: "BOOKED", color: "bg-muted/50 border-muted" },
            { label: "SELECTED", color: "bg-gold border-gold-light" },
          ].map((l) => (
            <div key={l.label} className="flex items-center gap-2">
              <div className={`w-5 h-5 rounded-sm border ${l.color}`} />
              <span className="text-xs font-medium">{l.label}</span>
            </div>
          ))}
        </div>

        {/* Screen */}
        <div className="text-center mb-8">
          <div className="h-1 gradient-gold-horizontal rounded-full max-w-xl mx-auto opacity-60" />
          <p className="text-xs text-muted-foreground uppercase tracking-[0.3em] mt-2">Screen This Way</p>
        </div>

        {/* Seats */}
        <div className="space-y-8 max-w-xl mx-auto">
          <div>
            <p className="text-center text-xs text-muted-foreground uppercase tracking-wider mb-3">Recliner — $28.00</p>
            {renderRow(recliners, "J")}
          </div>
          <div>
            <p className="text-center text-xs text-muted-foreground uppercase tracking-wider mb-3">Prime — $18.00</p>
            <div className="space-y-1">
              {renderRow(primeH, "H")}
              {renderRow(primeG, "G")}
            </div>
          </div>
        </div>

        {/* Booking Summary */}
        {selectedSeats.length > 0 && (
          <div className="max-w-xl mx-auto mt-8 bg-card rounded-xl p-6 border border-border">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Selected Seats</p>
                <div className="flex gap-2 mt-1">
                  {selectedSeats.map((s) => (
                    <span key={s.id} className="bg-gold text-primary-foreground text-xs font-bold px-2 py-1 rounded">{s.id}</span>
                  ))}
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground uppercase">Total Payable</p>
                <p className="text-2xl font-bold">${total.toFixed(2)}</p>
              </div>
            </div>
            <button
              onClick={() => navigate(`/movie/${id}/checkout?seats=${selectedSeats.map(s => s.id).join(",")}&total=${total}`)}
              className="w-full gradient-gold text-primary-foreground font-bold py-3 rounded-xl shadow-gold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
            >
              Confirm Booking →
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SeatSelection;
