import { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { Check, Download, Home, Share2, QrCode, Film, MapPin, Calendar, Clock, Armchair } from "lucide-react";

interface BookingData {
  bookingId: string;
  movieTitle: string;
  moviePoster: string;
  seats: string[];
  basePrice: number;
  foodItems: { name: string; qty: number; price: number }[];
  foodTotal: number;
  convenienceFee: number;
  gst: number;
  promoDiscount: number;
  promoCode: string;
  giftCardDeduction: number;
  giftCardCode: string;
  grandTotal: number;
  paymentMethod: string;
  bookingDate: string;
  cinema: string;
  screen: string;
  showDate: string;
  showTime: string;
}

const BookingConfirmation = () => {
  const [booking, setBooking] = useState<BookingData | null>(null);
  const [showConfetti, setShowConfetti] = useState(true);
  const ticketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const data = localStorage.getItem("pvr_booking");
    if (data) setBooking(JSON.parse(data));
    const timer = setTimeout(() => setShowConfetti(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const downloadTicket = () => {
    if (!ticketRef.current || !booking) return;

    // Create a printable HTML version
    const ticketHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PVR LUXE - Booking Ticket</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f5f5; padding: 40px; }
    .ticket { max-width: 480px; margin: 0 auto; background: #1a1a2e; color: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    .ticket-header { background: linear-gradient(135deg, #d4a54a, #b8860b); padding: 24px; text-align: center; }
    .ticket-header h1 { font-size: 24px; font-weight: 800; font-style: italic; letter-spacing: 2px; }
    .ticket-header p { font-size: 11px; margin-top: 4px; opacity: 0.8; letter-spacing: 1px; }
    .confirmed { background: #10b981; color: #fff; padding: 10px; text-align: center; font-weight: 700; font-size: 13px; letter-spacing: 2px; }
    .ticket-body { padding: 24px; }
    .movie-title { font-size: 22px; font-weight: 800; margin-bottom: 4px; }
    .booking-id { font-size: 11px; color: #d4a54a; letter-spacing: 1px; margin-bottom: 16px; }
    .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 16px 0; }
    .detail-item label { display: block; font-size: 9px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 2px; }
    .detail-item span { font-size: 14px; font-weight: 600; }
    .divider { border: none; border-top: 2px dashed #333; margin: 20px 0; }
    .price-row { display: flex; justify-between; font-size: 13px; margin-bottom: 6px; }
    .price-row span:first-child { color: #aaa; }
    .price-row.discount span { color: #10b981; }
    .total-row { display: flex; justify-content: space-between; font-size: 18px; font-weight: 800; padding-top: 12px; border-top: 1px solid #333; margin-top: 8px; }
    .total-row span:last-child { color: #d4a54a; }
    .qr-section { text-align: center; padding: 20px; background: #111; margin: 0 24px 24px; border-radius: 12px; }
    .qr-placeholder { width: 120px; height: 120px; background: #fff; margin: 0 auto 8px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 48px; }
    .qr-text { font-size: 10px; color: #888; }
    .footer { text-align: center; padding: 16px; font-size: 10px; color: #666; border-top: 1px solid #222; }
    .food-section { margin-top: 12px; }
    .food-item { display: flex; justify-content: space-between; font-size: 12px; color: #ccc; margin-bottom: 4px; }
  </style>
</head>
<body>
  <div class="ticket">
    <div class="ticket-header">
      <h1>PVR LUXE</h1>
      <p>PREMIUM CINEMA EXPERIENCE</p>
    </div>
    <div class="confirmed">✓ BOOKING CONFIRMED</div>
    <div class="ticket-body">
      <div class="movie-title">${booking.movieTitle}</div>
      <div class="booking-id">BOOKING ID: ${booking.bookingId}</div>
      <div class="details-grid">
        <div class="detail-item"><label>Cinema</label><span>${booking.cinema}</span></div>
        <div class="detail-item"><label>Screen</label><span>${booking.screen}</span></div>
        <div class="detail-item"><label>Date</label><span>${booking.showDate}</span></div>
        <div class="detail-item"><label>Time</label><span>${booking.showTime}</span></div>
        <div class="detail-item"><label>Seats</label><span>${booking.seats.join(", ")}</span></div>
        <div class="detail-item"><label>Category</label><span>Luxe Recliner</span></div>
      </div>
      ${booking.foodItems.length > 0 ? `
      <hr class="divider">
      <div class="food-section">
        <div style="font-size:12px;font-weight:700;margin-bottom:8px;color:#d4a54a;">🍿 Food & Beverages</div>
        ${booking.foodItems.map(f => `<div class="food-item"><span>${f.name} × ${f.qty}</span><span>$${(f.price * f.qty).toFixed(2)}</span></div>`).join("")}
      </div>
      ` : ""}
      <hr class="divider">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:#aaa;">Tickets (${booking.seats.length})</span><span>$${booking.basePrice.toFixed(2)}</span></div>
      ${booking.foodTotal > 0 ? `<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:#aaa;">Food & Bev</span><span>$${booking.foodTotal.toFixed(2)}</span></div>` : ""}
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;"><span style="color:#aaa;">Fees + GST</span><span>$${(booking.convenienceFee + booking.gst).toFixed(2)}</span></div>
      ${booking.promoDiscount > 0 ? `<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;color:#10b981;"><span>Promo (${booking.promoCode})</span><span>-$${booking.promoDiscount.toFixed(2)}</span></div>` : ""}
      ${booking.giftCardDeduction > 0 ? `<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;color:#10b981;"><span>Gift Card</span><span>-$${booking.giftCardDeduction.toFixed(2)}</span></div>` : ""}
      <div class="total-row"><span>Total Paid</span><span>$${booking.grandTotal.toFixed(2)}</span></div>
    </div>
    <div class="qr-section">
      <div class="qr-placeholder">🎬</div>
      <div class="qr-text">Scan at entry gate • ${booking.bookingId}</div>
    </div>
    <div class="footer">Thank you for choosing PVR LUXE • Enjoy your movie!</div>
  </div>
</body>
</html>`;

    const blob = new Blob([ticketHTML], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `PVR-LUXE-Ticket-${booking.bookingId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!booking) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">No booking found.</p>
          <Link to="/" className="text-gold hover:underline">Go to Home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 pb-24 md:pb-8 relative overflow-hidden">
      {/* Confetti animation */}
      {showConfetti && (
        <div className="fixed inset-0 z-50 pointer-events-none">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 rounded-full animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `-${Math.random() * 20}%`,
                backgroundColor: ["#d4a54a", "#10b981", "#3b82f6", "#ef4444", "#a855f7"][i % 5],
                animation: `fall ${2 + Math.random() * 2}s ease-in forwards`,
                animationDelay: `${Math.random() * 1}s`,
              }}
            />
          ))}
        </div>
      )}

      <style>{`
        @keyframes fall {
          to { transform: translateY(120vh) rotate(720deg); opacity: 0; }
        }
      `}</style>

      <div className="container py-8 max-w-2xl">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Check className="w-10 h-10 text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold mb-2">Booking Confirmed! 🎉</h1>
          <p className="text-muted-foreground">Your tickets have been booked successfully. Enjoy the movie!</p>
        </div>

        {/* Ticket Card */}
        <div ref={ticketRef} className="bg-card rounded-2xl border border-border overflow-hidden shadow-lg">
          {/* Ticket Header */}
          <div className="gradient-gold p-5 text-center">
            <h2 className="font-display text-2xl font-bold italic text-primary-foreground tracking-wider">PVR LUXE</h2>
            <p className="text-primary-foreground/70 text-xs tracking-widest uppercase mt-1">Premium Cinema Experience</p>
          </div>

          {/* Confirmed badge */}
          <div className="bg-emerald-500 text-white text-center py-2 text-xs font-bold tracking-widest">
            ✓ BOOKING CONFIRMED
          </div>

          {/* Ticket Body */}
          <div className="p-6">
            <h3 className="font-display text-2xl font-bold mb-1">{booking.movieTitle}</h3>
            <p className="text-xs text-gold tracking-widest mb-5">BOOKING ID: {booking.bookingId}</p>

            <div className="grid grid-cols-2 gap-5">
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <MapPin className="w-3 h-3" />
                  <span className="text-[10px] uppercase tracking-wider">Cinema</span>
                </div>
                <p className="font-semibold text-sm">{booking.cinema}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <Film className="w-3 h-3" />
                  <span className="text-[10px] uppercase tracking-wider">Screen</span>
                </div>
                <p className="font-semibold text-sm">{booking.screen}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <Calendar className="w-3 h-3" />
                  <span className="text-[10px] uppercase tracking-wider">Date</span>
                </div>
                <p className="font-semibold text-sm">{booking.showDate}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <Clock className="w-3 h-3" />
                  <span className="text-[10px] uppercase tracking-wider">Time</span>
                </div>
                <p className="font-semibold text-sm">{booking.showTime}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <Armchair className="w-3 h-3" />
                  <span className="text-[10px] uppercase tracking-wider">Seats</span>
                </div>
                <p className="font-semibold text-sm">{booking.seats.join(", ")}</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <span className="text-[10px] uppercase tracking-wider">Category</span>
                </div>
                <p className="font-semibold text-sm">Luxe Recliner</p>
              </div>
            </div>

            {/* Food Items */}
            {booking.foodItems.length > 0 && (
              <>
                <div className="border-t border-dashed border-border my-5" />
                <div>
                  <p className="text-sm font-bold text-gold mb-3">🍿 Food & Beverages</p>
                  <div className="space-y-2">
                    {booking.foodItems.map((f, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{f.name} × {f.qty}</span>
                        <span>${(f.price * f.qty).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Price Summary */}
            <div className="border-t border-dashed border-border my-5" />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tickets ({booking.seats.length})</span>
                <span>${booking.basePrice.toFixed(2)}</span>
              </div>
              {booking.foodTotal > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Food & Bev</span>
                  <span>${booking.foodTotal.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fees + GST</span>
                <span>${(booking.convenienceFee + booking.gst).toFixed(2)}</span>
              </div>
              {booking.promoDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Promo ({booking.promoCode})</span>
                  <span>-${booking.promoDiscount.toFixed(2)}</span>
                </div>
              )}
              {booking.giftCardDeduction > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Gift Card ({booking.giftCardCode})</span>
                  <span>-${booking.giftCardDeduction.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg pt-3 border-t border-border">
                <span>Total Paid</span>
                <span className="text-gold">${booking.grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* QR Section */}
            <div className="mt-6 bg-secondary rounded-xl p-5 text-center">
              <div className="w-28 h-28 bg-white rounded-xl mx-auto flex items-center justify-center mb-3">
                <QrCode className="w-20 h-20 text-background" />
              </div>
              <p className="text-xs text-muted-foreground">Scan at entry gate • {booking.bookingId}</p>
            </div>
          </div>

          <div className="text-center py-4 border-t border-border text-xs text-muted-foreground">
            Thank you for choosing PVR LUXE • Enjoy your movie! 🎬
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <button
            onClick={downloadTicket}
            className="flex items-center justify-center gap-2 gradient-gold text-primary-foreground font-bold py-3 rounded-xl hover:opacity-90 transition-opacity"
          >
            <Download className="w-5 h-5" /> Download Ticket
          </button>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: `PVR LUXE Ticket - ${booking.movieTitle}`, text: `Booking ${booking.bookingId} for ${booking.movieTitle} on ${booking.showDate} at ${booking.showTime}` });
              }
            }}
            className="flex items-center justify-center gap-2 bg-card border border-border text-foreground font-bold py-3 rounded-xl hover:border-gold/50 transition-colors"
          >
            <Share2 className="w-5 h-5" /> Share Ticket
          </button>
        </div>

        <Link
          to="/"
          className="flex items-center justify-center gap-2 mt-4 text-gold hover:text-gold-light transition-colors font-medium"
        >
          <Home className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    </div>
  );
};

export default BookingConfirmation;
