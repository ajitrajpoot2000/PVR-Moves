import { useParams, Link } from "react-router-dom";
import { Star, Play, ArrowRight } from "lucide-react";
import { movies, cinemas } from "@/data/movies";
import cast1 from "@/assets/cast-1.jpg";
import cast2 from "@/assets/cast-2.jpg";
import cast3 from "@/assets/cast-3.jpg";
import cast4 from "@/assets/cast-4.jpg";

const castMembers = [
  { name: "Julian Vance", role: "AS KAELEN", img: cast1 },
  { name: "Elara Thorne", role: "AS SERA", img: cast2 },
  { name: "Marcus Reed", role: "AS THE ARCHITECT", img: cast3 },
  { name: "Sia Novak", role: "AS LYRA", img: cast4 },
];

const MovieDetail = () => {
  const { id } = useParams();
  const movie = movies.find((m) => m.id === Number(id));
  if (!movie) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Movie not found</div>;

  return (
    <div className="min-h-screen pt-16">
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[400px]">
        <div className="absolute inset-0">
          <img src={movie.poster} alt={movie.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/30" />
        </div>
        <div className="container relative z-10 flex items-end h-full pb-10">
          <div className="flex gap-6 items-end">
            <img src={movie.poster} alt={movie.title} className="w-40 h-60 object-cover rounded-lg shadow-2xl hidden md:block" />
            <div>
              <div className="flex gap-2 mb-2">
                {movie.format.map((f) => (
                  <span key={f} className="text-xs font-bold px-2 py-0.5 border border-gold text-gold rounded">{f}</span>
                ))}
                <span className="text-xs text-muted-foreground">{movie.genre} • {movie.duration}</span>
              </div>
              <h1 className="font-display text-4xl md:text-6xl font-black uppercase">{movie.title}</h1>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 fill-gold text-gold" />
                  <span className="font-bold text-lg">{movie.rating}</span>
                  <span className="text-muted-foreground text-sm">/10</span>
                </div>
                {movie.rottenTomatoes && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">ROTTEN TOMATOES </span>
                    <span className="font-bold">{movie.rottenTomatoes}%</span>
                  </div>
                )}
                <button className="flex items-center gap-2 text-gold text-sm font-semibold">
                  <Play className="w-4 h-4 fill-gold" /> WATCH TRAILER
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container grid grid-cols-1 lg:grid-cols-3 gap-8 py-8 pb-24 md:pb-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Plot */}
          <div>
            <h2 className="font-display text-xl italic text-gold mb-3">The Plot</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{movie.description}</p>
          </div>

          {/* Cast */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl italic text-gold">Starring</h2>
              <span className="text-xs text-muted-foreground uppercase tracking-wider cursor-pointer hover:text-foreground">See Full Cast</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {castMembers.map((c) => (
                <div key={c.name}>
                  <img src={c.img} alt={c.name} loading="lazy" className="w-full aspect-square object-cover rounded-lg" width={512} height={640} />
                  <h4 className="font-body text-sm font-bold mt-2">{c.name}</h4>
                  <p className="text-xs text-muted-foreground uppercase">{c.role}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <div className="bg-card rounded-xl p-6 border border-border space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">DIRECTOR</span>
              <span className="font-semibold">{movie.director}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">RELEASE DATE</span>
              <span className="font-semibold">{movie.releaseDate}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">GENRE</span>
              <span className="font-semibold">{movie.genre}</span>
            </div>
          </div>

          <div className="bg-card rounded-xl p-6 border border-border">
            <h3 className="text-gold text-xs font-bold uppercase tracking-wider mb-3">Recommended Cinemas</h3>
            {cinemas.slice(0, 2).map((c) => (
              <div key={c.id} className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 bg-gold/20 rounded flex items-center justify-center text-gold text-xs font-bold">🎬</div>
                <div>
                  <p className="text-sm font-semibold">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{(c.id * 2.4).toFixed(1)} miles away</p>
                </div>
              </div>
            ))}
          </div>

          <Link
            to={`/movie/${movie.id}/showtimes`}
            className="gradient-gold text-primary-foreground font-bold text-sm px-6 py-4 rounded-xl shadow-gold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity w-full"
          >
            🎬 BOOK TICKETS <ArrowRight className="w-4 h-4" />
          </Link>

          <div className="bg-card rounded-xl p-6 border border-border">
            <div className="text-gold text-2xl mb-2">❝</div>
            <p className="text-sm italic text-muted-foreground">
              "A visually breathtaking masterclass in modern science fiction. A director's best work in years."
            </p>
            <div className="flex items-center gap-2 mt-3">
              <span className="bg-gold text-primary-foreground text-xs font-bold px-2 py-0.5 rounded">NY</span>
              <span className="text-xs font-semibold">THE NEW YORK TIMES</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;
