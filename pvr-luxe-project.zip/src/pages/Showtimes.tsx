import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { SlidersHorizontal, Heart, MapPin } from "lucide-react";
import { movies, cinemas } from "@/data/movies";

const statusColors = {
  available: "text-green-400",
  almost_full: "text-gold",
  filling_fast: "text-gold",
  sold_out: "text-muted-foreground",
};

const Showtimes = () => {
  const { id } = useParams();
  const movie = movies.find((m) => m.id === Number(id));
  const [selectedDate, setSelectedDate] = useState(0);

  const dates = [
    { day: "14", weekday: "THU", month: "MAR" },
    { day: "15", weekday: "FRI", month: "MAR" },
    { day: "16", weekday: "SAT", month: "MAR" },
    { day: "17", weekday: "SUN", month: "MAR" },
  ];

  if (!movie) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Movie not found</div>;

  return (
    <div className="min-h-screen pt-16">
      {/* Movie Header */}
      <section className="bg-card border-b border-border">
        <div className="container py-6 flex gap-6 items-center">
          <img src={movie.poster} alt={movie.title} className="w-32 h-48 object-cover rounded-lg" />
          <div>
            <div className="flex gap-2 mb-2">
              {movie.format.map((f) => (
                <span key={f} className="text-xs font-bold px-2 py-0.5 border border-gold text-gold rounded">{f}</span>
              ))}
              <span className="text-xs text-muted-foreground">{movie.certification} • {movie.duration}</span>
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-black uppercase">{movie.title}</h1>
            <p className="text-sm text-muted-foreground mt-2 max-w-lg">{movie.description}</p>
          </div>
        </div>
      </section>

      {/* Date Selector */}
      <section className="bg-card border-b border-border">
        <div className="container py-4 flex items-center gap-4">
          <div className="flex gap-2">
            {dates.map((d, i) => (
              <button
                key={i}
                onClick={() => setSelectedDate(i)}
                className={`flex flex-col items-center px-4 py-2 rounded-lg text-xs font-medium transition-colors ${
                  selectedDate === i
                    ? "bg-gold text-primary-foreground"
                    : "bg-secondary text-foreground hover:bg-muted"
                }`}
              >
                <span className="text-[10px] uppercase">{d.month}</span>
                <span className="text-lg font-bold">{d.day}</span>
                <span className="text-[10px] uppercase">{d.weekday}</span>
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 text-sm text-muted-foreground ml-auto">
            <SlidersHorizontal className="w-4 h-4" /> Filters
          </button>
        </div>
      </section>

      {/* Cinema Listings */}
      <div className="container py-8 space-y-6 pb-24 md:pb-8">
        {cinemas.map((cinema) => (
          <div key={cinema.id} className="bg-card rounded-xl p-6 border border-border">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-display text-lg font-bold">{cinema.name}</h3>
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                  <MapPin className="w-3 h-3" /> {cinema.location}
                </p>
                <div className="flex gap-2 mt-2">
                  {cinema.features.map((f) => (
                    <span key={f} className="text-[10px] font-semibold px-2 py-0.5 bg-secondary rounded">{f}</span>
                  ))}
                </div>
              </div>
              <Heart className="w-5 h-5 text-gold cursor-pointer" />
            </div>
            {cinema.showtimes.map((st) => (
              <div key={st.category} className="mb-4 last:mb-0">
                <p className="text-xs font-bold text-gold uppercase tracking-wider mb-2">
                  {st.category} • ${st.price.toFixed(2)}
                </p>
                <div className="flex gap-3 flex-wrap">
                  {st.times.map((t) => (
                    <Link
                      key={t.time}
                      to={t.status === "sold_out" ? "#" : `/movie/${id}/seats`}
                      className={`px-4 py-2 rounded-lg border text-center min-w-[100px] transition-colors ${
                        t.status === "sold_out"
                          ? "border-border bg-secondary/50 opacity-50 cursor-not-allowed"
                          : "border-border bg-secondary hover:border-gold hover:bg-gold/10"
                      }`}
                    >
                      <span className="text-sm font-semibold block">{t.time}</span>
                      <span className={`text-[10px] uppercase font-medium ${statusColors[t.status]}`}>
                        {t.status.replace("_", " ")}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Showtimes;
