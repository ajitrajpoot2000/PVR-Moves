import { Tag, Clock } from "lucide-react";

const offers = [
  { id: 1, title: "50% Off First Booking", description: "New users get 50% off on their first movie booking. Max discount $15.", code: "FIRST50", validity: "Valid till Apr 30", color: "from-gold to-amber-700" },
  { id: 2, title: "Buy 1 Get 1 Free", description: "Every Wednesday enjoy BOGO on all LUXE screens.", code: "WEDNESDAYBOGO", validity: "Every Wednesday", color: "from-emerald-600 to-teal-700" },
  { id: 3, title: "IMAX Special - $5 Off", description: "Get $5 off on all IMAX screenings this month.", code: "IMAX5", validity: "Valid till Mar 31", color: "from-blue-600 to-indigo-700" },
  { id: 4, title: "Combo Meal Deal", description: "Popcorn + Drink combo at just $9.99 with any ticket.", code: "COMBO999", validity: "Ongoing", color: "from-rose-600 to-pink-700" },
  { id: 5, title: "Student Discount 25%", description: "Show your student ID and get 25% off on weekday shows.", code: "STUDENT25", validity: "Weekdays only", color: "from-violet-600 to-purple-700" },
  { id: 6, title: "Family Pack", description: "Book 4+ tickets and get 20% off. Perfect for family outings.", code: "FAMILY20", validity: "Valid till May 15", color: "from-orange-600 to-red-700" },
];

const Offers = () => {
  return (
    <div className="min-h-screen bg-background pt-20 pb-24 md:pb-8">
      <div className="container">
        <div className="flex items-center gap-3 mb-2">
          <Tag className="w-7 h-7 text-gold" />
          <h1 className="font-display text-3xl font-bold text-foreground">Offers & Deals</h1>
        </div>
        <p className="text-muted-foreground mb-8 max-w-xl">Exclusive deals and discounts for PVR LUXE members.</p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {offers.map(offer => (
            <div key={offer.id} className="bg-surface-elevated rounded-xl overflow-hidden border border-border hover:border-gold/30 transition-colors">
              <div className={`bg-gradient-to-r ${offer.color} p-5`}>
                <h3 className="text-white font-bold text-lg">{offer.title}</h3>
              </div>
              <div className="p-5">
                <p className="text-muted-foreground text-sm mb-4">{offer.description}</p>
                <div className="flex items-center justify-between">
                  <div className="bg-background border border-dashed border-gold rounded-lg px-3 py-1.5">
                    <span className="text-gold font-mono font-bold text-sm">{offer.code}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>{offer.validity}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Offers;
