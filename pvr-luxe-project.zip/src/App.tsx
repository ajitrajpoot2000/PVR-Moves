import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navbar, BottomNav } from "@/components/Navbar";
import Index from "./pages/Index.tsx";
import MovieDetail from "./pages/MovieDetail.tsx";
import Showtimes from "./pages/Showtimes.tsx";
import SeatSelection from "./pages/SeatSelection.tsx";
import Checkout from "./pages/Checkout.tsx";
import Cinemas from "./pages/Cinemas.tsx";
import Offers from "./pages/Offers.tsx";
import FoodBev from "./pages/FoodBev.tsx";
import GiftCards from "./pages/GiftCards.tsx";
import BookingConfirmation from "./pages/BookingConfirmation.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/movie/:id" element={<MovieDetail />} />
          <Route path="/movie/:id/showtimes" element={<Showtimes />} />
          <Route path="/movie/:id/seats" element={<SeatSelection />} />
          <Route path="/movie/:id/checkout" element={<Checkout />} />
          <Route path="/movie/:id/confirmation" element={<BookingConfirmation />} />
          <Route path="/cinemas" element={<Cinemas />} />
          <Route path="/offers" element={<Offers />} />
          <Route path="/food-bev" element={<FoodBev />} />
          <Route path="/gift-cards" element={<GiftCards />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <BottomNav />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
