import poster1 from "@/assets/movie-poster-1.jpg";
import poster2 from "@/assets/movie-poster-2.jpg";
import poster3 from "@/assets/movie-poster-3.jpg";
import poster4 from "@/assets/movie-poster-4.jpg";
import poster5 from "@/assets/movie-poster-5.jpg";
import poster6 from "@/assets/movie-poster-6.jpg";

export interface Movie {
  id: number;
  title: string;
  genre: string;
  rating: number;
  duration: string;
  certification: string;
  format: string[];
  poster: string;
  description: string;
  director: string;
  releaseDate: string;
  rottenTomatoes?: number;
  status: "now_showing" | "coming_soon";
}

const posters = [poster1, poster2, poster3, poster4, poster5, poster6];

export const movies: Movie[] = [
  { id: 1, title: "Nebulous", genre: "Sci-Fi, Thriller", rating: 9.2, duration: "2h 45m", certification: "UA", format: ["IMAX 3D", "4DX"], poster: posters[0], description: "In a world where reality is questioned, a lone investigator uncovers a hidden sequence that suggests the reality they inhabit is a meticulously crafted simulation.", director: "Christopher Nolan", releaseDate: "July 21, 2024", rottenTomatoes: 98, status: "now_showing" },
  { id: 2, title: "Velvet Echoes", genre: "Romance, Drama", rating: 8.4, duration: "2h 10m", certification: "A", format: ["ICE"], poster: posters[1], description: "Two strangers connected by a mysterious melody find their lives intertwining across decades.", director: "Sofia Coppola", releaseDate: "Aug 15, 2024", rottenTomatoes: 91, status: "now_showing" },
  { id: 3, title: "Chronicles of Dust", genre: "Sci-Fi, Adventure", rating: 8.7, duration: "2h 30m", certification: "UA", format: ["4DX"], poster: posters[2], description: "On a dying planet, a scavenger discovers an ancient artifact that could save or destroy civilization.", director: "Denis Villeneuve", releaseDate: "Sep 5, 2024", rottenTomatoes: 94, status: "now_showing" },
  { id: 4, title: "Dragon's Reign", genre: "Fantasy, Action", rating: 8.9, duration: "2h 50m", certification: "UA", format: ["IMAX 3D"], poster: posters[3], description: "The last dragonlord must forge an alliance to defeat an ancient evil threatening to plunge the world into eternal darkness.", director: "George Miller", releaseDate: "Oct 1, 2024", rottenTomatoes: 96, status: "now_showing" },
  { id: 5, title: "Silent Whispers", genre: "Horror, Drama", rating: 7.8, duration: "1h 55m", certification: "UA", format: ["LUXE"], poster: posters[4], description: "A family moves into an ancestral home only to discover the walls hold memories of a terrifying past.", director: "Ari Aster", releaseDate: "Oct 15, 2024", rottenTomatoes: 88, status: "now_showing" },
  { id: 6, title: "Zero Gravity", genre: "Action, Drama", rating: 8.6, duration: "2h 20m", certification: "UA", format: ["IMAX 3D", "4DX"], poster: posters[5], description: "An astronaut stranded on a dying space station must find a way home before oxygen runs out.", director: "Alfonso Cuarón", releaseDate: "Nov 1, 2024", rottenTomatoes: 93, status: "now_showing" },
  { id: 7, title: "The Final Reel", genre: "Mystery, Thriller", rating: 8.1, duration: "2h 05m", certification: "U", format: ["LUXE"], poster: posters[2], description: "A film archivist discovers a lost movie that seems to predict real murders happening in the present day.", director: "David Fincher", releaseDate: "Nov 10, 2024", status: "now_showing" },
  { id: 8, title: "Neon Nights: The Ascension", genre: "Action, Sci-Fi", rating: 9.0, duration: "2h 45m", certification: "UA", format: ["IMAX 3D", "4DX"], poster: posters[0], description: "In a world where light is the only currency, one hacker must penetrate the core of the crystalline city to restore the stars.", director: "James Cameron", releaseDate: "Dec 1, 2024", rottenTomatoes: 95, status: "now_showing" },
  { id: 9, title: "Crimson Tide Rising", genre: "Action, Thriller", rating: 8.3, duration: "2h 15m", certification: "UA", format: ["4DX"], poster: posters[3], description: "A submarine crew faces impossible odds when rogue operatives seize control of a nuclear weapon.", director: "Tony Scott", releaseDate: "Dec 15, 2024", status: "now_showing" },
  { id: 10, title: "Emerald Skies", genre: "Adventure, Fantasy", rating: 8.5, duration: "2h 25m", certification: "U", format: ["IMAX 3D"], poster: posters[5], description: "A pilot discovers a hidden civilization above the clouds that holds the key to Earth's salvation.", director: "Hayao Miyazaki", releaseDate: "Jan 5, 2025", status: "now_showing" },
  { id: 11, title: "Phantom Protocol", genre: "Spy, Thriller", rating: 8.8, duration: "2h 10m", certification: "UA", format: ["IMAX 3D", "LUXE"], poster: posters[2], description: "A disavowed agent must go deep undercover to prevent a global catastrophe.", director: "Christopher McQuarrie", releaseDate: "Jan 20, 2025", rottenTomatoes: 90, status: "now_showing" },
  { id: 12, title: "Autumn Sonata", genre: "Drama, Music", rating: 8.0, duration: "2h 00m", certification: "U", format: ["LUXE"], poster: posters[1], description: "A concert pianist returns home to reconcile with her estranged daughter.", director: "Greta Gerwig", releaseDate: "Feb 1, 2025", status: "now_showing" },
  { id: 13, title: "Iron Frontier", genre: "Western, Action", rating: 8.2, duration: "2h 35m", certification: "UA", format: ["4DX"], poster: posters[3], description: "In a steampunk Wild West, a bounty hunter tracks a gang of outlaws wielding forbidden technology.", director: "Quentin Tarantino", releaseDate: "Feb 15, 2025", status: "now_showing" },
  { id: 14, title: "Deep Current", genre: "Thriller, Drama", rating: 7.9, duration: "1h 50m", certification: "UA", format: ["LUXE"], poster: posters[4], description: "A marine biologist discovers an underwater anomaly that could change our understanding of life itself.", director: "James Wan", releaseDate: "Mar 1, 2025", status: "now_showing" },
  { id: 15, title: "Binary Stars", genre: "Sci-Fi, Romance", rating: 8.6, duration: "2h 15m", certification: "U", format: ["IMAX 3D"], poster: posters[5], description: "Two astronauts on different missions communicate through quantum-entangled messages across light-years.", director: "Christopher Nolan", releaseDate: "Mar 15, 2025", rottenTomatoes: 92, status: "now_showing" },
  { id: 16, title: "Glass Kingdom", genre: "Fantasy, Drama", rating: 8.4, duration: "2h 20m", certification: "UA", format: ["IMAX 3D", "LUXE"], poster: posters[0], description: "A child prodigy discovers she can reshape reality through her crystalline sculptures.", director: "Guillermo del Toro", releaseDate: "Apr 1, 2025", status: "now_showing" },
  { id: 17, title: "Shadow Weaver", genre: "Horror, Fantasy", rating: 7.7, duration: "1h 45m", certification: "UA", format: ["4DX"], poster: posters[4], description: "An ancient spirit begins weaving nightmares into reality in a small coastal town.", director: "Robert Eggers", releaseDate: "Apr 15, 2025", status: "now_showing" },
  { id: 18, title: "Copper & Chrome", genre: "Action, Sci-Fi", rating: 8.8, duration: "2h 30m", certification: "UA", format: ["IMAX 3D", "4DX"], poster: posters[0], description: "In a retrofuturistic metropolis, a detective and an android partner to solve the crime of the century.", director: "Ridley Scott", releaseDate: "May 1, 2025", rottenTomatoes: 89, status: "now_showing" },
  { id: 19, title: "Monsoon Hearts", genre: "Romance, Drama", rating: 8.1, duration: "2h 05m", certification: "U", format: ["LUXE"], poster: posters[1], description: "During India's monsoon season, two souls find love in the most unexpected circumstances.", director: "Mira Nair", releaseDate: "May 15, 2025", status: "now_showing" },
  { id: 20, title: "Apex Predator", genre: "Action, Thriller", rating: 8.5, duration: "2h 25m", certification: "UA", format: ["IMAX 3D", "4DX"], poster: posters[3], description: "In the Amazon rainforest, a rescue team becomes the hunted when they encounter an ancient apex predator.", director: "John Carpenter", releaseDate: "Jun 1, 2025", status: "now_showing" },
  { id: 21, title: "Synthesis: Reborn", genre: "Sci-Fi, Action", rating: 0, duration: "2h 40m", certification: "UA", format: ["IMAX 3D"], poster: posters[0], description: "The sequel to the acclaimed Synthesis saga brings new revelations.", director: "Marcus Thorne", releaseDate: "Oct 26, 2025", status: "coming_soon" },
  { id: 22, title: "The Midnight Ticket", genre: "Mystery, Romance", rating: 0, duration: "2h 00m", certification: "U", format: ["LUXE"], poster: posters[1], description: "A mysterious cinema shows films that haven't been made yet.", director: "Elena Vance", releaseDate: "Nov 12, 2025", status: "coming_soon" },
  { id: 23, title: "Echoes of the North", genre: "Adventure, Drama", rating: 0, duration: "2h 30m", certification: "UA", format: ["4DX"], poster: posters[5], description: "A Nordic expedition uncovers a civilization frozen in time beneath the ice.", director: "Soren Holm", releaseDate: "Dec 5, 2025", status: "coming_soon" },
];

export const cinemas = [
  {
    id: 1,
    name: "PVR LUXE, Director's Cut",
    location: "Ambience Mall, Vasant Kunj, New Delhi",
    features: ["M-TICKET", "FOOD & BEV", "VALET"],
    showtimes: [
      { category: "LUXE RECLINERS", price: 45, times: [
        { time: "10:45 AM", status: "almost_full" as const },
        { time: "02:15 PM", status: "available" as const },
        { time: "06:30 PM", status: "available" as const },
        { time: "09:45 PM", status: "available" as const },
      ]},
      { category: "GOLD CLASS", price: 32, times: [
        { time: "11:00 AM", status: "sold_out" as const },
        { time: "03:30 PM", status: "filling_fast" as const },
      ]},
    ],
  },
  {
    id: 2,
    name: "PVR IMAX, Select Citywalk",
    location: "Saket District Centre, New Delhi",
    features: ["IMAX LASER", "DOLBY ATMOS"],
    showtimes: [
      { category: "IMAX EXPERIENCE", price: 28, times: [
        { time: "12:30 PM", status: "available" as const },
        { time: "04:15 PM", status: "available" as const },
        { time: "08:00 PM", status: "filling_fast" as const },
        { time: "11:30 PM", status: "available" as const },
      ]},
    ],
  },
];
